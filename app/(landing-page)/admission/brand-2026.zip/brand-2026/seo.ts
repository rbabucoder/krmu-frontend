export const SeoData = {
  title: "Brand 2026 | K.R. Mangalam University",
  description:
    "Apply for LLB Admissions 2026 at K.R. Mangalam University.",
  shareImage: "https://krmangalam.edu.in/og/law.jpg",
};
